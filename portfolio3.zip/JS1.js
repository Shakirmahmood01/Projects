// JavaScript source code
function showSearch(){
	var search=document.getElementById("searchDB");
	if (search.style.display==="none"){
    	search.style.display="block";
    }
	else{
    	search.style.display="none";
    }
}

function hideSearch(){
	var search=document.getElementById("searchDB");
	search.style.display="none";
}


function showFields(inputID){
	var titleInput=document.getElementById("titleInput");
	var dateInput=document.getElementById("dateInput");
	var btn=document.getElementById('btn');

	if (inputID==='titleInput'){
    	titleInput.style.display='block';
    	dateInput.style.display='none';
    	btn.style.display='block';
    }
	else if(inputID==='dateInput'){
    	titleInput.style.display='none';
    	dateInput.style.display='block';
    	btn.style.display='block';
    }
}

function validTitle(){
	var title=document.getElementById('titleInput');
	var titleLength=title.value;
	if (title.style.display!="none" && title.value===""){
        alert("Enter a title");
    	return false;
    } 
	else{
    	return true;
    }
}


function showDetails(id){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
      		document.getElementById("projectDetails").innerHTML = this.responseText;
    	}
  	};
  	xhttp.open("GET", "checkAllRows.php?id=" + id, true);
  	xhttp.send();

}


