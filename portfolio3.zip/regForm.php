<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Register</title>
    <link rel="stylesheet" href="css1.css" />
    <script src="Script1.js"></script>
</head>
<body>

    <form id="register" method="post" action="register.php">
        <label>Username:</label>
        <input type="text" name="userName"required /><br />

        <label>Password:</label>
        <input type="password" name="password" required /><br />

        <label>Confirm Password:</label>
        <input type="password" name="confPassword" required /><br />
	
        
        <label>Email: </label>
        <input type="email" name="email" required /><br/>
        
        <input type="submit" name="submit" value="Register" />

</body>
</html>
