<?php
require_once "dbDetails.php";

$conn = mysqli_connect($servername, $username, $password, $dbName);

if (!$conn) {
  die("connection failed: " . mysqli_connect_error());
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

$statement = mysqli_prepare($conn, "SELECT * FROM projects WHERE id = ?");
mysqli_stmt_execute($statement);
$result = mysqli_stmt_get_result($statement);


if (mysqli_num_rows($result) > 0) {
  $row = mysqli_fetch_assoc($result);
  echo "<h2>" . $row["title"] . "</h2>";
  echo "<p>Start date: " . $row["start_date"] . "</p>";
  echo "<p>End date: " . $row["end_date"] . "</p>";
  echo "<p>Phase: " . $row["phase"] . "</p>";
  echo "<p>Description: " . $row["description"] . "</p>";
} 
else {
  echo "No data found";
}

mysqli_stmt_close($statement);
mysqli_close($conn);
?>
