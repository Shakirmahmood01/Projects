<?php
require_once "dbDetails.php";
	
$userName = $_POST["userName"];
$passWord = $_POST["passWord"];

if (empty($passWord)) {
  die("Password field cannot be empty");
}

else if(empty($userName)){
	die ("Username field cannot be empty");
}

$conn = mysqli_connect($servername, $username, $password,  $dbName);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$statement = mysqli_prepare($conn, "SELECT * FROM users WHERE username = $userName AND password = $passWord");
mysqli_stmt_bind_param($statement, "ss", $userName, $passWord);
mysqli_stmt_execute($statement);
$result = mysqli_stmt_get_result($statement);

if(mysqli_num_rows($result) == 1){
  session_start();
  $_SESSION["loggedIn"] = true;
  header("location: user.php");
  exit;
}
else{
  echo "Invalid Credentials";
  header("location: login.php");
}

mysqli_stmt_close($statement);
mysqli_close($conn);
?>
