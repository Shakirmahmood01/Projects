<?php
require_once "dbDetails.php";

$conn = mysqli_connect($servername,$username,$password, $dbName);

if (!$conn){
    die("connection failed: " . mysqli_connect_error());
}

if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $statement = mysqli_prepare($conn, "SELECT * FROM projects WHERE title LIKE '%$search%' OR start_date = '$search'");
} else if (isset($_GET['date'])) {
    $date = mysqli_real_escape_string($conn, $_GET['date']);
    $statement = mysqli_prepare($conn, "SELECT * FROM projects WHERE start_date = '$date'");
} else {
    $statement = mysqli_prepare($conn, "SELECT title, start_date, description FROM projects");
}


mysqli_stmt_execute($statement);
$result = mysqli_stmt_get_result($statement);
?>

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Home</title>
    <link rel="stylesheet" href="css1.css" />
    <script src="JS1.js"></script>
</head>
<body>
    <nav id="nav1">
        <ul>
            <!--  Basic navigation bar on each page-->
            <li>
                <a href="part1.php">Home</a>
            </li>
            <li>
                <a href="login.php">Log in</a>
            </li>
        </ul>
    </nav>


    <nav id="nav2">
        <ul>
            <li>
                <a href="#viewDB" onclick="hideSearch()" >View Projects</a>
            </li>
            <li>
                <a href="#searchDB" onclick="showSearch()" >Search Database</a>
            </li>
        </ul>
    </nav>

    <table id="viewDB">
        <tr>
            <th>Title</th>
            <th>Start Date</th>
            <th>Description</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "<tr class='proj' onclick='showDetails(" . $row["id"] . ")'>";;
                echo "<td class='title'>" . $row["title"] . "</td>";
                echo "<td class='date'>" . $row["start_date"] . "</td>";
                echo "<td class='desc'>" . $row["description"] . "</td>";
                echo "</tr>";
            }
        }else{
            echo "<tr><td colspan='3'>No data found</td></tr>";
        }
        mysqli_stmt_close($statement);
        mysqli_close($conn);
        ?>
    </table>
<!--------------------------------View clicked item------------------------------------->
        
<div id="projectDetails"></div>

        
        
        
        
<!-------------------------------Search DB using filter-------------------------------------------->
    <div id="searchDB" style="display:none;">
        <p id="search" style="font-size:20px; padding-left:10px;">
        Search Database:
		<br>
		<br>
        </p>
        <form method="GET" id="searchForm" style="padding:10px;" onsubmit="return validTitle()">
            <label> Search by Title: <input type="radio" name="option" value="title" onclick="showFields('titleInput')"></label>
			<br>
			<input type="text" style="display:none;" name="search" id="titleInput" placeholder="Enter Title">
			<br>
			<label> Search by Date: <input type="radio" name="option" value="date" onclick="showFields('dateInput')"></label>
			<br>
			<input type="date" style="display:none;" name="date" id="dateInput">
			<br>
			<input type="submit" id="btn" value="Submit" onclick="if(document.querySelector('input[name=option]:checked').value==='title') return validTitle();" style="display:none;">


        </form>

    </div>
<!-------------------------------Showing DB items based on inputs----------------------->
	<div id="viewSearchedDB">
        <?php
		if (mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "<tr class='project'>";
                echo "<td class='Title'>" . $row["title"] . "</td>";
                echo "<td class='stdate'>" . $row["start_date"] . "</td>";
            	echo "<td class='endate'>" . $row["end_date"] . "</td>";
            	echo "<td class='phase'>" . $row["phase"] . "</td>";
                echo "<td class='desc'>" . $row["description"] . "</td>";
                echo "</tr>";
            }
        }else{
            echo "<tr><td colspan='3'>No data found</td></tr>";
        }
        mysqli_stmt_close($statement);
        mysqli_close($conn);
        ?>
            
	</div>
        
            
</body>
</html>


