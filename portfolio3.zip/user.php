<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}



require_once "dbDetails.php";
$conn = mysqli_connect($servername,$username, $password, $dbName);

$statement = mysqli_prepare($conn, "SELECT * FROM projects");
$result = mysqli_stmt_get_results($statement);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logged In</title>
</head>
<body>
    <h1>These are the current records in the DB. Click the corresponding button to add another project or edit a current project:</h1>
    <table id="viewDB">
        <tr>
            <th>Title</th>
            <th>Start Date</th>
            <th>Description</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "<tr class='proj'>";
                echo "<td class='title'>" . $row["title"] . "</td>";
                echo "<td class='date'>" . $row["start_date"] . "</td>";
                echo "<td class='eDate'>" . $row["end_date"] . "</td>";
                echo "<td class='phase'>" . $row["phase"] . "</td>";
                echo "<td class='desc'>" . $row["description"] . "</td>";
                echo "<td class='userAssigned'>" . $row["uid"] . "</td>";
                echo "</tr>";
            }
        }else{
            echo "<tr><td colspan='3'>No data found</td></tr>";
        }
        mysqli_stmt_close($statement);
        mysqli_close($conn);
        ?>
    </table>

    <br><br>
    <a href="logout.php">Log Out</a>
</body>
</html>