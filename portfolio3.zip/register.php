<?php
	if (isset($_POST['submit'])) {

    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $confPassword = $_POST['confPassword'];
    $email = $_POST['email'];

    if (empty($password)) {
        die("Password field cannot be empty.");
    }
    
    if($password!=$confPassword){
    	die ("Passwords must match");
    }

    require_once "dbDetails.php";

    $conn = mysqli_connect($servername, $username, $password,  $dbName);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    

    $sql = "SELECT * FROM users WHERE username='$userName'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
    	die("Username already exists.");
	}

	$sql = "SELECT * FROM users WHERE email='$email'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
    	die("Email already exists.");
	}


    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password, email) VALUES ('$userName', '$hashed_password', '$email')";

    if (mysqli_query($conn, $sql)) {
        header('Location: login.php');
    	echo "Registered Successfully";

    } else {
        echo "Cannot register";
    }

    mysqli_close($conn);
}

?>



?>