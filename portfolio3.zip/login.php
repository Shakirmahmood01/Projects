<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login</title>
    <link rel="stylesheet" href="css1.css" />
    <script src="Script1.js"></script>
</head>
<body>

    <nav id="nav1">
        <ul>
            <!--  Basic navigation bar on each page-->
            <li><a href="part1.php">Home</a></li>
            <li><a href="login.php">Log in</a></li>
        </ul>
    </nav>

	<form id="login" method="post" action="checkLogin.php">
        <label><b>Username: 
        </b>
        </label>
        <input type="text" name="userName" id="uName" placeholder="Enter Username">
        <br><br>
        <label><b>Password: </b></label>
        <input type="Password" name="passWord" id="pWord" placeholder="Enter Password">
        <br><br>
        <input type="submit" name="log" id="btnLogin" value="Log In">
        
		<input  href="regForm.php" type="button" name="reg" id="btnRegister" value="Register" onclick="window.location.href='regForm.php';">
    </form>


</body>
</html>