<?php
$servername = "localhost";
$username = "u-210165854";
$password = "2NYFxrXWD8LJWil";
$dbName = "u_210165854_db";
?>