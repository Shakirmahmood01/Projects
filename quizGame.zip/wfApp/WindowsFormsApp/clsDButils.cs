﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.OleDb;

namespace WindowsFormsApp
{
    public static class clsDButils
    {
        private static OleDbConnection con;
        private static OleDbDataReader reader;
        private static OleDbCommand cmd;
        private static Boolean validUser;
        private static string dbName = "project.accdb";

        public static void connectToDB()
        {
            // set-up the connection to the DB
            con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=" + dbName);

            // open the connection to DB
            con.Open();
        }

        /// <summary>
        /// ///////////
        /// </summary>
        public static void closeConnection()
        {
            con.Close();
        }

        ///////////////
        ///////////////////////////////
        public static Boolean addUser(string strUserName, string strEmail,string strNewPW, string strQ1Ans, string strQ2Ans, string strQ3Ans)
        {
            Boolean retVal;

            // set-up the connection to the DB
            connectToDB();

            cmd = new OleDbCommand("INSERT INTO users (userName, email, userPW, q1Ans,q2Ans,q3Ans) VALUES (@userName,@email,@userPW,@q1Ans,@q2Ans,@q3Ans)", con);

            cmd.Parameters.AddWithValue("@userName", strUserName);
            cmd.Parameters.AddWithValue("@email", strEmail);
            cmd.Parameters.AddWithValue("@userPW", strNewPW);
            cmd.Parameters.AddWithValue("@q1Ans", strQ1Ans);
            cmd.Parameters.AddWithValue("@q2Ans", strQ2Ans);
            cmd.Parameters.AddWithValue("@q3Ans", strQ3Ans);

            // open the connection and execute the command
            try
            {
                // open the connection to DB
                //con.Open();

                // execute the SQL query
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                    retVal = false;
                else
                    retVal = true;

            }
            catch (Exception ex)
            {
                // issue found - something went wrong
                MessageBox.Show(ex.Message);
                retVal = false;
            }

            // close connection to DB
            closeConnection();

            return retVal;

        } // addUser

        //////////////////////////////////////////////////////
        ///
        public static Boolean upDatePassword(string strUserName, string strNewPW)
        {
            Boolean retVal;

            // set-up the connection to the DB
            connectToDB();

            // create the query
            cmd = new OleDbCommand("UPDATE users SET userPW = @newPW Where userName = @userName", con);

            //cmd.Text = "UPDATE users SET userPW = @newPW Where userName = @userName";
            cmd.Parameters.AddWithValue("@newPW", strNewPW);
            cmd.Parameters.AddWithValue("@userName", strUserName);

            //MessageBox.Show(sqlQuery);

            retVal = false;

            // open the connection and execute the command
            try
            {
                // execute the SQL query
                cmd.ExecuteNonQuery();

                retVal = true;

            }
            catch (Exception ex)
            {
                // issue found - something went wrong
                MessageBox.Show(ex.Message);
                retVal = false;
            }

            // close connection to DB
            closeConnection();

            return retVal;

        } // upDatePassword

        /// <summary>
        /// runs the given query and returns the count of records found
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public static int noOfRecs(string sqlQuery)
        {
            int recCount;
            //string sqlQuery;

            recCount = 0;

            //sqlQuery= "SELECT count(*) as RowCount, * FROM " + tableName;

            cmd = new OleDbCommand(sqlQuery, con);

            // open the connection and execute the command
            try
            {
                // execute the SQL query
                recCount = (Int32) cmd.ExecuteScalar();

            }
            catch (Exception ex)
            {
                // issue found - something went wrong
                MessageBox.Show(ex.Message);
            }

            // close connection to DB
            //con.Close();

            return recCount;
        } // noOfRecs

        /// <summary>
        /// //////////////
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <returns></returns>
        public static OleDbDataReader getData(string sqlQuery)
        {
            cmd = new OleDbCommand(sqlQuery, con);

            // open the connection and execute the command
            try
            {
                // execute the SQL query
                reader = cmd.ExecuteReader();

                // did we find the user?
                if (reader.HasRows)
                {
                    // yes
                    return reader;
                }
                else
                    return null;

            }
            catch (Exception ex)
            {
                // issue found - something went wrong
                MessageBox.Show(ex.Message);
            }

            // close connection to DB
            //con.Close();

            return null;
        } // getData

        public static Boolean updateScore(string strUserName, int score,int highestScore,int numberOfGamesPlayed,int totalScore)
        {
            Boolean retVal;

            // set-up the connection to the DB
            connectToDB();

            // create the query
            cmd = new OleDbCommand("UPDATE users SET lastScore = @score, highestScore = @highestScore, numberOfGamesPlayed = @numberOfGamesPlayed, totalScore = @totalScore Where userName = @userName", con);
            //cmd = new OleDbCommand("UPDATE users SET lastScore = @score, highestScore = @highestScore Where userName = @userName", con);

            cmd.Parameters.AddWithValue("@lastScore", score);
            cmd.Parameters.AddWithValue("@highestScore", highestScore);
            cmd.Parameters.AddWithValue("@numberOfGamesPlayed", numberOfGamesPlayed);
            cmd.Parameters.AddWithValue("@totalScore", totalScore);
            cmd.Parameters.AddWithValue("@userName", strUserName);

            //MessageBox.Show(sqlQuery);

            retVal = false;

            try
            {
                // execute the SQL query
                cmd.ExecuteNonQuery();

                retVal = true;

            }
            catch (Exception ex)
            {
                // issue found - something went wrong
                MessageBox.Show(ex.Message);
                retVal = false;
            }

            // close connection to DB
            closeConnection();

            return retVal;

        } // updateScore


    } // clsDButils

}
