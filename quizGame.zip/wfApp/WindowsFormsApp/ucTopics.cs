﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class ucTopics : UserControl
    {
        private static ucTopics _instance;
        private string _category;
        private int _questionDifficulty;
        private string _gameType;
        private ucGameZone _ucGameZone=null;

        public static ucTopics Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucTopics();
                return _instance;
            }
        }

        public ucTopics()
        {
            InitializeComponent();
        }

        /// <summary>
        /// return the topic selected
        /// </summary>
        public string Category
        {
            get
            {
                return this._category;
            }

            set
            {
                this._category = value;
            }
        }

        public string gameType
        {
            get
            {
                return this._gameType;
            }
            set
            {
                this._gameType = value;
            }
        }

        public int questionDifficulty
        {
            get
            {
                return this._questionDifficulty;
            }
            set
            {
                this._questionDifficulty = value;
            }
        }

        private void ucTopics_Load(object sender, EventArgs e)
        {
            // assume the default is NORMAL and BASIC
            gameType = clsUtilis.NORMAL;
            questionDifficulty = clsUtilis.BASIC;

        }

        private void llSports_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Category = clsUtilis.SPORTS;

            // display the gameZone panel
            displayGameZonePanel();

        }

        /// <summary>
        /// dislay the game zone panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void displayGameZonePanel()
        {
            // display the gameZone panel
            if (_ucGameZone != null)
            {
                mainWindow.Instance.mainPanelContainer.Controls.Remove(_ucGameZone);
                _ucGameZone.Dispose();
                _ucGameZone = null;
            }

            _ucGameZone = new ucGameZone();
            mainWindow.Instance.mainPanelContainer.Controls.Add(_ucGameZone);
            _ucGameZone.Dock = DockStyle.Fill;
            _ucGameZone.BringToFront();
            _ucGameZone.Show();

        } //displayGameZonePanel


        // update game type property
        private void rbNormal_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNormal.Checked)
                gameType = clsUtilis.NORMAL;
        }
        private void rbTimed_CheckedChanged(object sender, EventArgs e)
        {
            if (rbTimed.Checked)
                gameType = clsUtilis.TIMED;
        }

        private void rbChallenge_CheckedChanged(object sender, EventArgs e)
        {
            if (rbChallenge.Checked)
                gameType = clsUtilis.CHALLENGE;
        }

        // update game difficulty property
        private void rbAdvance_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAdvance.Checked)
                questionDifficulty = clsUtilis.ADVANCE;
        }

        private void rbBasic_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBasic.Checked)
                questionDifficulty = clsUtilis.BASIC;
        }

        private void rbExpert_CheckedChanged(object sender, EventArgs e)
        {
            if (rbExpert.Checked)
                questionDifficulty = clsUtilis.EXPERT;
        }

        private void gDifficulty_Enter(object sender, EventArgs e)
        {

        }
    }
}
