﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp
{
    public static class clsUtilis
    {
        public readonly static string SPORTS = "Sports";
        public readonly static string GEOGRAPHY = "Geography";
        public readonly static string GENERAL_KNOWLEDGE = "General Knowledge";
        public readonly static string HISTORY = "History";

        public readonly static int BASIC = 1;
        public readonly static int ADVANCE = 2;
        public readonly static int EXPERT = 3;


        public readonly static string NORMAL = "Normal";
        public readonly static string TIMED = "Timed";
        public readonly static string CHALLENGE = "Challenge";

        public readonly static int TIME_OUT = 30; // game time-out

        private static int MANTISSA_SIZE = 23;
        private readonly static int EXPONENT_SIZE = 8;


        /// <summary>
        /// returns true if the supplied address is in the correct format
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// converts a float which is less than 1 into its binary format
        /// i.e. it converts the fractional part of a float into its binnary format
        /// number like 0.435 and NOT 2.435
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static string fractionToBin(float inNum)
        {
            Char [] aChar;
            float result;
            float number;
            string binnary = "";

            aChar = new Char[32];

            number = inNum;

            result = 0.0f;
            do
            {
                result = (number * 2);

                if (result >= 1.0f)
                    binnary = binnary + "1";
                else
                    binnary = binnary + "0";

                // take the result and extract the fractional part from it
                string strResult = result.ToString();
                // find the decimal point position within the number
                int decPointPos = strResult.IndexOf(".");
                if (decPointPos > 0)
                {
                    // now extract the fractional part from the floating point number
                    string strFratctPart = strResult.Substring(decPointPos);
                    // append zero to it
                    strFratctPart = "0" + strFratctPart;
                    // convert it into a
                    Boolean validNum = (float.TryParse(strFratctPart, out number));
                }

                // repeat until result = 1 or until have done 23 bits 
            } while ((result != 1.0f) && (binnary.Length<23));



            return binnary;

        }

        /// <summary>
        /// appends zeros to the front of a string
        /// number of zeros appended depends on the length of the string
        /// maximum number of zeros that it will add will be 3
        /// </summary>
        /// <param name="strInNum"></param>
        /// <returns></returns>
        private static string apendZeros(string strInNum)
        {
            int noOfZerosToApend;
            string strNum;
            string strTmp;

            strNum = strInNum;
            noOfZerosToApend = 0;
            if (strNum.Length < 4)
                noOfZerosToApend = (4 - strNum.Length);
            else
            {
                int rem = (strNum.Length % 4); // remainder
                if (rem !=0)
                    noOfZerosToApend = (4 -rem);
            }

            //noOfZerosToApend = MAX_SIZE - strNum.Length;

            strTmp = "";
            for (int i=0;i<noOfZerosToApend;i++)
            {
                strTmp = strTmp + "0";
            }

            strNum = strTmp + strInNum;

            return strNum;
        } // apendZeros


        /// <summary>
        /// converts a decimal number to its binnary format
        /// if the supplied number is a negative number then it will use two's complement
        /// number of bits assumed to the converted number will be a multiple of 4
        /// e.g. 4 = 0100, 2 = 0010, 8 = 1000, 16 = 00010000
        /// </summary>
        /// <param name="inNum"></param>
        /// <returns></returns>
        public static string decToBin(int inNum, Boolean prefixZeros)
        {

            //            uint q;
            int q;
            string rem;
            //            uint numToConvert =(uint)inNum;
            int numToConvert;
            string strInNum;
            Boolean negativeNum;

            numToConvert = inNum;

            // is it a negative number?
            negativeNum = false;
            if (inNum < 0)
            {
                // make it a +ve number
                inNum = 0 - inNum;

                negativeNum = true;

                strInNum = inNum.ToString();

                //int tmpNum;
                //string strTmpNum =  //strNumber.Substring(1, strNumber.Length - 1);
                Boolean validNum = (int.TryParse(strInNum, out numToConvert));

                //numToConvert = tmpNum;
            }

            // convert to bin
            rem = "";
            q = 0;
            while (numToConvert >= 1)
            {
                q = numToConvert / 2;

                // get the remainder
                rem += (numToConvert % 2).ToString();
                numToConvert = q;
            }

            // gether the bits and put them the right way i.e. LSB is bit 0 and the MSB is bit 31
            string binary = "";
            for (int i = rem.Length - 1; i >= 0; i--)
            {
                binary = binary + rem[i];
            }

            if (prefixZeros)
                binary = apendZeros(binary);

            // is it a negative number?
            if (negativeNum)
            {

                string twosComp = "";
                string twosCompTmp = "";
                for (int i = 0; i<binary.Length; i++)
                {
                    if (binary[i] == '1')
                        twosComp = twosComp + "0";
                    else
                        twosComp = twosComp + "1";

                }

                Boolean c = false;
                Char[] aChar;
                int x = binary.Length + 1;

                aChar = new Char[x];
                for (int i=0;i<x;i++)
                {
                    aChar[i] = '0';
                }

                for (int i = twosComp.Length - 1; i >= 0; i--)
                {
                    if ((i == twosComp.Length - 1) && (twosComp[i] == '1'))
                    {
                        twosCompTmp = "0";
                        c = true;
                        aChar[i] = '0';
                    }
                    else if ((i == twosComp.Length - 1) && (twosComp[i] == '0'))
                    {
                        twosCompTmp = "1";
                        c = false;
                        aChar[i] = '1';
                    }
                    else
                    {
                        if ((c == true) && (twosComp[i] == '1'))
                        {
                            twosCompTmp = twosCompTmp + "0";
                            c = true;
                            aChar[i] = '0';

                        }
                        else if ((c == true) && (twosComp[i] == '0'))
                        {
                            twosCompTmp = twosCompTmp + "1";
                            c = false;
                            aChar[i] = '1';

                        }
                        else
                        {
                            twosCompTmp = twosCompTmp + twosComp[i];
                            aChar[i] = twosComp[i];

                        }
                    }
                }
                binary = new string(aChar);
            }

            return binary;
        } // decToBin

        /// <summary>
        /// converts a float of single type into its binary equivalent
        ///  inNum is expected to be like 34.890625
        /// </summary>
        /// <param name="inNum"></param>
        /// <returns></returns>
        public static string convertFloatToBin(float inNum)
        {
            int dotPos;
            Boolean negativeNum;
            string binary = "";
            string strInNum;
            string strIntegralPart;
            string strFracPart;

            // if negative number then turn it into a positive number for conversion purposes
            negativeNum = false;
            if (inNum < 0)
            {
                inNum = 0 - inNum;
                // need to remember that it is a -ve number because will need 
                // to add a sign bit of "1" to the front if it is a -ve number
                // or a sign bit of "0" if it is a +ve number
                negativeNum = true;
            }

            // convert the floating point number into its string format
            strInNum = inNum.ToString("R");

            // break the number into integral and fractional parts
            // e.g. if the number is 123.456 then
            // integral part is 123 and the fractional part is 0.456

            // get the position of "."
            dotPos = strInNum.IndexOf(".");

            // get the integral part
            strIntegralPart = strInNum.Substring(0, dotPos);

            // get the fractional part
            strFracPart = "0" + strInNum.Substring(dotPos);

            // now convert the string representation of integral part and fractional parts into numbers
            // i.e. change string into numbers
            int integralPart;
            float fracPart;
            Boolean validNum;

            // change the integral part into a number
            validNum = (int.TryParse(strIntegralPart, out integralPart));

            // change the fractional part into a number
            validNum = (float.TryParse(strFracPart, out fracPart));

            // convert the integral part into its binnary format
            string step1a = clsUtilis.decToBin(integralPart, false);

            // convert the fractional part into its binnary format
            string step1b = clsUtilis.fractionToBin(fracPart);

            // create an un-normalised floating point number by combining the integral part and fractional part
            // this will give a number like 10110.10011111
            string unNormNum = step1a + "." + step1b;

            // step 2
            // now norlalise the number
            // i.e. turn a number like 10110.10011111 into 1.011010011111*2^4
            // this is similar to writing a number like 7865.456 as 7.865456*10^3

            string norNum;
            dotPos = unNormNum.IndexOf(".");
            string strM1 = unNormNum.Substring(0, dotPos);
            string strE1 = unNormNum.Substring(dotPos + 1);
            norNum = strM1.Substring(0, 1) + "." + strM1.Substring(1) + strE1;

            // step 3
            // get the exponent
            int e2 = dotPos - 1;
            e2 = 127 + e2;
            // convert the exponent to binary format
            string strE2 = clsUtilis.decToBin(e2, true);

            // step 4
            if (negativeNum)
            {
                binary = "1" + strE2 + strM1.Substring(1) + strE1;
            }
            else
            {
                binary = "0" + strE2 + strM1.Substring(1) + strE1;
            }

            return binary;

        } // convertFloatToBin


        /// <summary>
        /// returns the decimal equivalent of inNum in string format
        /// </summary>
        /// <param name="inNum"></param>
        /// <returns></returns>
        public static string binToDec(string inNum)
        {
            int dec = 0;
            string strDec = "";

            for (int i = 0; i < inNum.Length; i++)
            {
                // we start with the least significant digit, and work our way to the left
                if (inNum[inNum.Length - i - 1] == '0') continue;
                dec += (int)Math.Pow(2, i);
            }

            strDec = dec.ToString();

            return strDec;

        } // binToDec


        /// <summary>
        /// expect an input of binary format of a float point number
        /// the number to be converted is expected to be in 'single' format i.e. exponent is 8 bits and mantissa is 23 bits
        /// </summary>
        /// <param name="inNum"></param>
        /// <returns></returns>
        public static string convertBinToFloat(string inNum)
        {
            string strFloat="0.00";
            string strMentissa;
            float mentissa;
            string strExp;
            int exp;
            string strInNum;
            float convertedNum;

            // inNum is expected to be of the format
            // s 8 bits exponent and 23 bits mentissa e.g. 01010010010010000110001100000000
            // s = 0, exponent = 10100100, mentissa = 10010000110001100000000

            strInNum = inNum;
            strExp = strInNum.Substring(1, EXPONENT_SIZE);
            strMentissa = strInNum.Substring(EXPONENT_SIZE + 1);

            strExp = binToDec(strExp);

            Boolean validNum = (int.TryParse(strExp, out exp));

            // Since there is the positive and negative range of +- 127 
            // for exponents 127 has to be subtracted from the the converted value
            exp = exp - 127;

            mentissa = 0.0f;
            for (int i = 0; i < strMentissa.Length; i++)
            {
                // we start with the left most bit and work towards the right
                if (strMentissa[i] == '0') continue;
                mentissa += (float)Math.Pow(2, -(i+1)); 
                // basically 2^-i but because i starts at 0 we need to add 1 to it before raising the power
            }
            mentissa = 1.0f + mentissa;
            convertedNum = mentissa * (float)Math.Pow(2, exp);
            return strFloat;
        } // convertBinToFloat

    }
}
