﻿namespace WindowsFormsApp
{
    partial class ucViewProfile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblRank = new System.Windows.Forms.Label();
            this.txtRank = new System.Windows.Forms.TextBox();
            this.lblHighScore = new System.Windows.Forms.Label();
            this.txtHighestScore = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLastLogin = new System.Windows.Forms.TextBox();
            this.txtAvgScore = new System.Windows.Forms.TextBox();
            this.txtLastGameScore = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Blue;
            this.lblName.Location = new System.Drawing.Point(34, 216);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(141, 59);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(395, 232);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(507, 38);
            this.txtName.TabIndex = 1;
            // 
            // lblRank
            // 
            this.lblRank.AutoSize = true;
            this.lblRank.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRank.ForeColor = System.Drawing.Color.Blue;
            this.lblRank.Location = new System.Drawing.Point(987, 473);
            this.lblRank.Name = "lblRank";
            this.lblRank.Size = new System.Drawing.Size(121, 59);
            this.lblRank.TabIndex = 0;
            this.lblRank.Text = "Rank";
            // 
            // txtRank
            // 
            this.txtRank.Location = new System.Drawing.Point(1316, 473);
            this.txtRank.Name = "txtRank";
            this.txtRank.ReadOnly = true;
            this.txtRank.Size = new System.Drawing.Size(133, 38);
            this.txtRank.TabIndex = 1;
            // 
            // lblHighScore
            // 
            this.lblHighScore.AutoSize = true;
            this.lblHighScore.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHighScore.ForeColor = System.Drawing.Color.Blue;
            this.lblHighScore.Location = new System.Drawing.Point(34, 457);
            this.lblHighScore.Name = "lblHighScore";
            this.lblHighScore.Size = new System.Drawing.Size(290, 59);
            this.lblHighScore.TabIndex = 0;
            this.lblHighScore.Text = "Highest Score";
            // 
            // txtHighestScore
            // 
            this.txtHighestScore.Location = new System.Drawing.Point(395, 473);
            this.txtHighestScore.Name = "txtHighestScore";
            this.txtHighestScore.ReadOnly = true;
            this.txtHighestScore.Size = new System.Drawing.Size(133, 38);
            this.txtHighestScore.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(34, 343);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(346, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Last Game Score";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(987, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(302, 59);
            this.label2.TabIndex = 0;
            this.label2.Text = "Average Score";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(34, 557);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 59);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Login";
            // 
            // txtLastLogin
            // 
            this.txtLastLogin.Location = new System.Drawing.Point(395, 573);
            this.txtLastLogin.Name = "txtLastLogin";
            this.txtLastLogin.ReadOnly = true;
            this.txtLastLogin.Size = new System.Drawing.Size(133, 38);
            this.txtLastLogin.TabIndex = 3;
            // 
            // txtAvgScore
            // 
            this.txtAvgScore.Location = new System.Drawing.Point(1316, 359);
            this.txtAvgScore.Name = "txtAvgScore";
            this.txtAvgScore.ReadOnly = true;
            this.txtAvgScore.Size = new System.Drawing.Size(133, 38);
            this.txtAvgScore.TabIndex = 4;
            // 
            // txtLastGameScore
            // 
            this.txtLastGameScore.Location = new System.Drawing.Point(395, 359);
            this.txtLastGameScore.Name = "txtLastGameScore";
            this.txtLastGameScore.ReadOnly = true;
            this.txtLastGameScore.Size = new System.Drawing.Size(133, 38);
            this.txtLastGameScore.TabIndex = 5;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(1316, 232);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(507, 38);
            this.txtEmail.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(987, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 59);
            this.label4.TabIndex = 6;
            this.label4.Text = "Email";
            // 
            // ucViewProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtLastGameScore);
            this.Controls.Add(this.txtAvgScore);
            this.Controls.Add(this.txtLastLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtHighestScore);
            this.Controls.Add(this.txtRank);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblHighScore);
            this.Controls.Add(this.lblRank);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Name = "ucViewProfile";
            this.Size = new System.Drawing.Size(2275, 1122);
            this.Load += new System.EventHandler(this.ucViewProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblRank;
        private System.Windows.Forms.TextBox txtRank;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.TextBox txtHighestScore;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLastLogin;
        private System.Windows.Forms.TextBox txtAvgScore;
        private System.Windows.Forms.TextBox txtLastGameScore;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label4;
    }
}
