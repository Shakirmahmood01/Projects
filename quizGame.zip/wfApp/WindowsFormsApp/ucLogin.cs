﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace WindowsFormsApp
{

    /// <summary>
    /// ////////////////////////////////////////////////////////////////////
    /// </summary>
    public partial class ucLogin: UserControl
    {

        private static ucLogin _instance;
        private static string _userName;
        private string _passWord;


        public static ucLogin Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucLogin();

                return _instance;
            }
        }

        public ucLogin()
        {
            InitializeComponent();
        }


        //*******************************************************************
        public string userName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
            }
        }

        //*******************************************************************
        public string passWord
        {
            get
            {
                return _passWord;
            }
            set
            {
                _passWord = value;
            }
        }



        //*******************************************************************
        // will check if the supplied user name and the PW exist within the DB
        private Boolean checkUser(string userName, string userPW)
        {
            string sqlQuery;
            OleDbDataReader reader;
            Boolean validUser;

            sqlQuery = "SELECT * FROM users WHERE userName = '" + userName + "' AND  userPW  = '" + userPW + "'";

            // set-up the connection to the DB
            clsDButils.connectToDB();
            
            // execute the SQL query
            reader = clsDButils.getData(sqlQuery);

            validUser = false;
            if (reader != null)
                validUser = true;

            // close connection to DB
            clsDButils.closeConnection();

            return validUser;
            
        } // checkUser




        //*******************************************************************
        // this is called when the 'Login' button is pressed
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string strPW;
            string strUserName;
            string sqlQuery;
            OleDbDataReader reader;
            int highestScore;
            int score;


            // get typed PW
            strPW = clsEncrypt.encryptTxt(txtPW.Text);

            // store the encrypted pw in the class variable
            this.passWord = strPW;

            // get the types in user name
            strUserName = txtUserName.Text;

            // store the user name in the class variable
            this.userName = strUserName;

            // check if the user name and PW are valid i.e. it is a registered user
            if (checkUser(strUserName, strPW))
            {
                // valid user

                ////// TO DO
                ///update the last login date in the DB

                //MessageBox.Show("Valid User");

                //Console.WriteLine(strPW);

                mainWindow.Instance.mainPanelContainer.Dock = DockStyle.Fill;
                mainWindow.Instance.mainPanelContainer.Show();
                mainWindow.Instance.mainPanelContainer.BringToFront();

                // display the buttons on the left panel
                mainWindow.Instance.showLeftSidePanelControls();

                // display the logout button
                mainWindow.Instance.sidePanelContainerLeft.Controls["btnLogout"].Show();

                // get the users score/heighest score

                sqlQuery = "SELECT * FROM users WHERE userName = '" + this.userName + "'";

                // set-up the connection to the DB
                clsDButils.connectToDB();

                // execute the SQL query
                reader = clsDButils.getData(sqlQuery);

                highestScore = 0;
                score = 0;

                if (reader != null)
                {
                    // should only get 1 record
                    while (reader.Read())
                    {
                        score = (int)reader["lastScore"];
                        highestScore = (int)reader["highestScore"];
                    }
                }

                // close connection to DB
                clsDButils.closeConnection();

                // display the user name and his last game and heighest score
                mainWindow.Instance.showBottomPanelControls();
                mainWindow.Instance.bottomPanelContainer.Controls["lblUser"].Text = userName;
                mainWindow.Instance.bottomPanelContainer.Controls["lblLastGameScore"].Text = score.ToString();
                mainWindow.Instance.bottomPanelContainer.Controls["lblHighestScore"].Text = highestScore.ToString();

                // hide the login panel
                this.Hide();

            }
            else
                MessageBox.Show("User name or the password entered incorrectly.");


        } // btnLogin_Click


        //*******************************************************************
        private void btnResetForm_Click(object sender, EventArgs e)
        {
            txtUserName.Clear();
            txtPW.Clear();
        }

        //*******************************************************************
        private void txtResetPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            // display the reset PW panel
            if (!mainWindow.Instance.mainPanelContainer.Controls.Contains(ucResetPW.Instance))
            {
                mainWindow.Instance.mainPanelContainer.Controls.Add(ucResetPW.Instance);
                ucResetPW.Instance.Dock = DockStyle.Fill;
                ucResetPW.Instance.BringToFront();
            }
            else
            {
                ucResetPW.Instance.Show();
                ucResetPW.Instance.BringToFront();
            }

            // hide the login panel
            this.Hide();
        }

        private void ucLogin_Load(object sender, EventArgs e)
        {
            // set focus on the user name
            this.txtUserName.Select();
        }

        private void txtRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            // display the reset PW panel
            if (!mainWindow.Instance.mainPanelContainer.Controls.Contains(ucRegister.Instance))
            {
                mainWindow.Instance.mainPanelContainer.Controls.Add(ucRegister.Instance);
                ucRegister.Instance.Dock = DockStyle.Fill;
                ucRegister.Instance.BringToFront();
            }
            else
            {
                ucRegister.Instance.Show();
                ucRegister.Instance.BringToFront();
            }

            // hide the login panel
            this.Hide();
        }
    }
}
