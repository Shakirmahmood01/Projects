﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp
{
    public partial class ucViewProfile : UserControl
    {
        private static ucViewProfile _instance;

        public static ucViewProfile Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucViewProfile();
                return _instance;
            }
        }

        public ucViewProfile()
        {
            InitializeComponent();
        }


        private void ucViewProfile_Load(object sender, EventArgs e)
        {
            displayUserData();
        } // ucViewProfile_Load

        /// <summary>
        // get the logged-in user data and display it
        /// </summary>
        public void displayUserData()
        {
            string strUserName;
            string sqlQuery;
            OleDbDataReader reader;
            int highestScore = 0;
            int lastGameScore = 0;
            string emailAddress = "";
            int userRanking = 0;
            int avgScore = 0;
            int noOfGamesPlayed = 0;
            DateTime lastLoginDate = new DateTime(1900, 01, 01);
            int totalScore = 0;


            // get the loged-in user detail
            strUserName = ucLogin.Instance.userName;


            // set-up the query

            sqlQuery = "SELECT * FROM users WHERE userName = '" + strUserName + "'";

            // set-up the connection to the DB
            clsDButils.connectToDB();

            // execute the SQL query
            reader = clsDButils.getData(sqlQuery);

            highestScore = 0;

            if (reader != null)
            {
                // should only get 1 record
                while (reader.Read())
                {
                    highestScore = (int)reader["highestScore"];
                    lastGameScore = (int)reader["lastScore"];
                    emailAddress = (string)reader["email"];
                    noOfGamesPlayed = (int)reader["numberOfGamesPlayed"];
                    lastLoginDate = (DateTime)reader["dateLastLoggedin"];
                    totalScore = (int)reader["totalScore"];
                } // while

                txtName.Text = strUserName;
                txtEmail.Text = emailAddress;
                txtLastGameScore.Text = lastGameScore.ToString();
                txtHighestScore.Text = highestScore.ToString();
                txtLastLogin.Text = lastLoginDate.ToString();

                avgScore = totalScore / noOfGamesPlayed;
                txtAvgScore.Text = avgScore.ToString();

            }

            // close connection to DB
            clsDButils.closeConnection();

            // now work-out the users ranking
            userRanking = calculateUserRanking(strUserName);
            txtRank.Text = userRanking.ToString();

        } // displayUserData

        /// <summary>
        /// runs a query on the DB to get the ranking of the supplied user
        /// </summary>
        /// <param name="userHighestScore"></param>
        /// <returns></returns>
        private int calculateUserRanking(string userName)
        {
            string sqlQuery;
            OleDbDataReader reader;
            int ranking = 0;


            //sqlQuery = "SELECT t1.userName, t1.highestScore, COUNT(*) AS rank FROM users AS t1 LEFT JOIN users as t2 ON t1.highestScore <= t2.highestScore GROUP BY t1.highestScore,t1.userName";
            sqlQuery = "SELECT (SELECT COUNT(*) FROM users WHERE highestScore >= t2.highestScore) as Rank,userName  FROM users as t2 ORDER BY highestScore,userName";

            // set-up the connection to the DB
            clsDButils.connectToDB();

            // execute the SQL query
            reader = clsDButils.getData(sqlQuery);

            if (reader != null)
            {
                // go through every record and store in the array
                while (reader.Read())
                {
                    if (userName == reader.GetString(1))
                    {
                        ranking = reader.GetInt32(0);
                        break;
                    }

                } // while

            }
            else
            {
                MessageBox.Show("No records found in the DB!");
            }

            // close connection to DB
            clsDButils.closeConnection();

            return ranking;

        } // calculateUserRanking

        public void resetControls()
        {
            txtName.Text = "";
            txtEmail.Text = "";
            txtLastGameScore.Text = "";
            txtHighestScore.Text = "";
            txtLastLogin.Text = "";
            txtAvgScore.Text = "";
            txtRank.Text = "";
        }

} // ucViewProfile
}
