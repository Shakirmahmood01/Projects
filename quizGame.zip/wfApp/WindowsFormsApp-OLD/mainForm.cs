﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class mainWindow : Form
    {

        private static mainWindow _instance;

        public static mainWindow Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new mainWindow();

                return _instance;
            }
        }

        public Panel mainPanelContainer
        {
            get { return mainPanel; }
            set { mainPanel = value; }
        }
        public Panel sidePanelContainerLeft
        {
            get { return sidePanelLeft; }
            set { sidePanelLeft = value; }
        }
        public Panel topPanelContainer
        {
            get { return topPanel; }
            set { topPanel = value; }
        }
        public Panel bottomPanelContainer
        {
            get { return bottomPanel; }
            set { bottomPanel = value; }
        }

        public mainWindow()
        {
            InitializeComponent();
        }

        public void setScore(string value)
        {
                this.lblScore.Text = value;
        }

        //*******************************************************************
        private void btnChooseTopic_Click(object sender, EventArgs e)
        {
            // put the marker next to the topic button
            marker.Height = btnChooseTopic.Height;
            marker.Top = btnChooseTopic.Top;

            // display the topic panel
            if (!mainPanel.Controls.Contains(ucTopics.Instance))
            {
                mainPanel.Controls.Add(ucTopics.Instance);
                ucTopics.Instance.Dock = DockStyle.Fill;
                ucTopics.Instance.BringToFront();
            }
            else
            {
                ucTopics.Instance.Show();
                ucTopics.Instance.BringToFront();
            }
        }

        public void hideTimeLeftFields()
        {
            this.topPanelContainer.Controls["lblTimeLeft"].Text = "";
            this.topPanelContainer.Controls["lblTimeLeft"].Hide();
            this.topPanelContainer.Controls["Label6"].Hide();
        }
        public void showTimeLeftFields()
        {
            mainWindow.Instance.topPanelContainer.Controls["lblTimeLeft"].Show();
            mainWindow.Instance.topPanelContainer.Controls["Label6"].Show();

        }

        /// <summary>
        /// hide the top panel controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void hideTopPanelControls()
        {
            this.topPanel.Controls["lblGameDifficulty"].Text="";
            this.topPanel.Controls["lblGameType"].Text = "";
            this.topPanel.Controls["lblTopic"].Text = "";
            this.topPanel.Controls["lblScore"].Text = "";

            this.topPanel.Controls["lblGameDifficulty"].Hide();
            this.topPanel.Controls["lblGameType"].Hide();
            this.topPanel.Controls["lblTopic"].Hide();
            this.topPanel.Controls["lblScore"].Hide();
            this.topPanel.Controls["label1"].Hide();
            this.topPanel.Controls["label2"].Hide();
            this.topPanel.Controls["label3"].Hide();
            this.topPanel.Controls["label4"].Hide();
            this.topPanel.Controls["label6"].Hide();

        } // hideTopPanelControls

        /// <summary>
        /// show the top panel controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void showTopPanelControls()
        {
            this.topPanel.Controls["lblGameDifficulty"].Show();
            this.topPanel.Controls["lblGameType"].Show();
            this.topPanel.Controls["lblTopic"].Show();
            this.topPanel.Controls["lblScore"].Show();
            this.topPanel.Controls["label1"].Show();
            this.topPanel.Controls["label2"].Show();
            this.topPanel.Controls["label3"].Show();
            this.topPanel.Controls["label4"].Show();

        } // showTopPanelControls


        public void showBottomPanelControls()
        {
            this.bottomPanel.Controls["lblUser"].Text="--";
            this.bottomPanel.Controls["lblLastGameScore"].Text = "--";
            //this.bottomPanel.Controls["label5"].Text = "";
            //this.bottomPanel.Controls["label7"].Text = "";
            this.bottomPanel.Controls["lblHeighestScore"].Text="--";

            this.bottomPanel.Controls["lblUser"].Show();
            this.bottomPanel.Controls["lblLastGameScore"].Show();
            this.bottomPanel.Controls["label5"].Show();
            this.bottomPanel.Controls["label7"].Show();
            this.bottomPanel.Controls["lblHeighestScore"].Show();


        } // showBottomPanelControls

        public void hideBottomPanelControls()
        {
            this.bottomPanel.Controls["lblUser"].Hide();
            this.bottomPanel.Controls["lblLastGameScore"].Hide();
            this.bottomPanel.Controls["label5"].Hide();
            this.bottomPanel.Controls["label7"].Hide();
            this.bottomPanel.Controls["lblHeighestScore"].Hide();

        } // hideBottomPanelControls

        //*******************************************************************
        private void mainWindow_Load(object sender, EventArgs e)
        {

            _instance = this;

            // display the login form
            this.displayLoginForm();

            this.hideTopPanelControls();

            this.hideBottomPanelControls();
            this.hideTimeLeftFields();

        }

        //*******************************************************************
        // display the login form
        private void displayLoginForm()
        {
            // display the login form
            ucLogin ucLogin_ = new ucLogin();
            ucLogin_.Dock = DockStyle.Fill;
            mainPanel.Controls.Add(ucLogin_);
            ucLogin_.BringToFront();

            // hide the buttons
            hideLeftSidePanelControls();


        }

        /// <summary>
        /// Hide the left side panel buttons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void hideLeftSidePanelControls()
        {
            this.Controls["sidePanelLeft"].Controls["btnLogout"].Hide();
            this.Controls["sidePanelLeft"].Controls["btnChooseTopic"].Hide();
            this.Controls["sidePanelLeft"].Controls["btnViewAccInfo"].Hide();
            this.Controls["sidePanelLeft"].Controls["marker"].Hide();

        } // hideLeftSidePanelControls

        /// <summary>
        /// Show the left side panel buttons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void showLeftSidePanelControls()
        {
            this.Controls["sidePanelLeft"].Controls["btnLogout"].Show();
            this.Controls["sidePanelLeft"].Controls["btnChooseTopic"].Show();
            this.Controls["sidePanelLeft"].Controls["btnViewAccInfo"].Show();
            this.Controls["sidePanelLeft"].Controls["marker"].Show();

        } // showLeftSidePanelControls

        //*******************************************************************
        private void btnViewAccInfo_Click(object sender, EventArgs e)
        {

            // put the marker next to the topic button
            this.marker.Height = btnViewAccInfo.Height;
            this.marker.Top = btnViewAccInfo.Top;

            // display the topic panel
            if (!mainPanel.Controls.Contains(ucViewProfile.Instance))
            {
                mainPanel.Controls.Add(ucViewProfile.Instance);
                ucViewProfile.Instance.Dock = DockStyle.Fill;
                ucViewProfile.Instance.BringToFront();
            }
            else
            {
                ucViewProfile.Instance.Show();
                ucViewProfile.Instance.BringToFront();
            }
        }

        //*******************************************************************
        private void btnLogout_Click(object sender, EventArgs e)
        {

            // update the user logout time in the DB


            this.hideBottomPanelControls();

            // display the login form
            // display the login form
            this.displayLoginForm();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
