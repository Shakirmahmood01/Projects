﻿namespace WindowsFormsApp
{
    partial class ucGameZone
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnEndGame = new System.Windows.Forms.Button();
            this.btnSubmitAns = new System.Windows.Forms.Button();
            this.gAns = new System.Windows.Forms.GroupBox();
            this.rbAns3 = new System.Windows.Forms.RadioButton();
            this.rbAns2 = new System.Windows.Forms.RadioButton();
            this.rbAns1 = new System.Windows.Forms.RadioButton();
            this.lblQno = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gAns.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnEndGame);
            this.panel1.Controls.Add(this.btnSubmitAns);
            this.panel1.Controls.Add(this.gAns);
            this.panel1.Controls.Add(this.lblQno);
            this.panel1.Controls.Add(this.lblQuestion);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2275, 1122);
            this.panel1.TabIndex = 0;
            // 
            // btnEndGame
            // 
            this.btnEndGame.BackColor = System.Drawing.Color.Silver;
            this.btnEndGame.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndGame.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEndGame.Location = new System.Drawing.Point(562, 751);
            this.btnEndGame.Name = "btnEndGame";
            this.btnEndGame.Size = new System.Drawing.Size(358, 74);
            this.btnEndGame.TabIndex = 24;
            this.btnEndGame.Text = "End Game";
            this.btnEndGame.UseVisualStyleBackColor = false;
            this.btnEndGame.Click += new System.EventHandler(this.btnEndGame_Click);
            // 
            // btnSubmitAns
            // 
            this.btnSubmitAns.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnSubmitAns.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitAns.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSubmitAns.Location = new System.Drawing.Point(171, 751);
            this.btnSubmitAns.Name = "btnSubmitAns";
            this.btnSubmitAns.Size = new System.Drawing.Size(358, 74);
            this.btnSubmitAns.TabIndex = 24;
            this.btnSubmitAns.Text = "Submit Answer";
            this.btnSubmitAns.UseVisualStyleBackColor = false;
            this.btnSubmitAns.Click += new System.EventHandler(this.btnSubmitAns_Click);
            // 
            // gAns
            // 
            this.gAns.Controls.Add(this.rbAns3);
            this.gAns.Controls.Add(this.rbAns2);
            this.gAns.Controls.Add(this.rbAns1);
            this.gAns.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gAns.Location = new System.Drawing.Point(150, 263);
            this.gAns.Name = "gAns";
            this.gAns.Size = new System.Drawing.Size(1834, 450);
            this.gAns.TabIndex = 1;
            this.gAns.TabStop = false;
            this.gAns.Text = "Answers";
            // 
            // rbAns3
            // 
            this.rbAns3.AutoSize = true;
            this.rbAns3.Location = new System.Drawing.Point(21, 311);
            this.rbAns3.Name = "rbAns3";
            this.rbAns3.Size = new System.Drawing.Size(169, 36);
            this.rbAns3.TabIndex = 2;
            this.rbAns3.TabStop = true;
            this.rbAns3.Text = "Answer 3";
            this.rbAns3.UseVisualStyleBackColor = true;
            // 
            // rbAns2
            // 
            this.rbAns2.AutoSize = true;
            this.rbAns2.Location = new System.Drawing.Point(21, 186);
            this.rbAns2.Name = "rbAns2";
            this.rbAns2.Size = new System.Drawing.Size(169, 36);
            this.rbAns2.TabIndex = 1;
            this.rbAns2.TabStop = true;
            this.rbAns2.Text = "Answer 2";
            this.rbAns2.UseVisualStyleBackColor = true;
            // 
            // rbAns1
            // 
            this.rbAns1.AutoSize = true;
            this.rbAns1.Location = new System.Drawing.Point(21, 73);
            this.rbAns1.Name = "rbAns1";
            this.rbAns1.Size = new System.Drawing.Size(169, 36);
            this.rbAns1.TabIndex = 0;
            this.rbAns1.TabStop = true;
            this.rbAns1.Text = "Answer 1";
            this.rbAns1.UseVisualStyleBackColor = true;
            // 
            // lblQno
            // 
            this.lblQno.AutoSize = true;
            this.lblQno.ForeColor = System.Drawing.Color.Red;
            this.lblQno.Location = new System.Drawing.Point(165, 174);
            this.lblQno.Name = "lblQno";
            this.lblQno.Size = new System.Drawing.Size(53, 32);
            this.lblQno.TabIndex = 0;
            this.lblQno.Text = "Q#";
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.ForeColor = System.Drawing.Color.Red;
            this.lblQuestion.Location = new System.Drawing.Point(279, 174);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(130, 32);
            this.lblQuestion.TabIndex = 0;
            this.lblQuestion.Text = "Question";
            // 
            // ucGameZone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "ucGameZone";
            this.Size = new System.Drawing.Size(2275, 1122);
            this.Load += new System.EventHandler(this.ucGameZone_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gAns.ResumeLayout(false);
            this.gAns.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gAns;
        private System.Windows.Forms.RadioButton rbAns3;
        private System.Windows.Forms.RadioButton rbAns2;
        private System.Windows.Forms.RadioButton rbAns1;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Button btnEndGame;
        private System.Windows.Forms.Button btnSubmitAns;
        private System.Windows.Forms.Label lblQno;
    }
}
