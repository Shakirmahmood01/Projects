﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Windows.Threading;
using System.Windows.Input;

namespace WindowsFormsApp
{
    public partial class ucGameZone : UserControl
    {

        private int questionDifficulty;
        private string Category;
        private string gameType;
        private string[] question;
        private string[] ans1;
        private string[] ans2;
        private string[] ans3;
        private string[] correctAns;
        private int nextQ;
        private int recCount;
        private int _score;
        private DispatcherTimer dispatcherTimer;
        private int timeLeft;
        private Boolean atLeastOneQanswered;


        private static ucGameZone _instance;

        public static ucGameZone Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucGameZone();
                return _instance;
            }
        }

        public ucGameZone()
        {
            InitializeComponent();
        }

        public int score
        {
            get
            {
                return this._score;
            }

            set
            {
                this._score = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ucGameZone_Load(object sender, EventArgs e)
        {
            string sqlQuery;
            OleDbDataReader reader;
            int i;

            // initialise score
            score = 0;

            atLeastOneQanswered = false;

            // show top panel controls in the main window
            mainWindow.Instance.showTopPanelControls();

            // hide the buttons on the left panel
            mainWindow.Instance.hideLeftSidePanelControls();

            // get game type, topic etc
            questionDifficulty = ucTopics.Instance.questionDifficulty;
            Category = ucTopics.Instance.Category.ToString();
            gameType = ucTopics.Instance.gameType;

            mainWindow.Instance.topPanelContainer.Controls["lblGameDifficulty"].Text = questionDifficulty.ToString();
            mainWindow.Instance.topPanelContainer.Controls["lblTopic"].Text = Category;
            mainWindow.Instance.topPanelContainer.Controls["lblGameType"].Text = ucTopics.Instance.gameType;
            //this.topPanel.Controls["lblScore"].Show();

            // get the required data from the DB
            // set-up the connection to the DB
            clsDButils.connectToDB();
            
            // setup the qury to get the count of questions for the category and the difficulty selected
            // this is required to size the arrays that would hold the data
            sqlQuery = "SELECT COUNT(*) FROM gameQuestions WHERE category = '" + Category + "' AND  questionDifficulty  = " + questionDifficulty;

            recCount = 0;
            recCount = clsDButils.noOfRecs(sqlQuery);

            if (recCount > 0)
            {
                // create the arrays of the required size to hold the data
                question = new string[recCount];
                ans1 = new string[recCount];
                ans2 = new string[recCount];
                ans3 = new string[recCount];
                correctAns = new string[recCount];

                // setup the qury to get the questions for the category and the difficulty selected
                sqlQuery = "SELECT question,ans1,ans2,ans3,correctAns FROM gameQuestions WHERE category = '" + Category + "' AND  questionDifficulty  = " + questionDifficulty;

                // execute the SQL query to get the data
                reader = clsDButils.getData(sqlQuery);

                // get the data into the appropriate array
                i = 0;
                while (reader.Read())
                {
                    lblQuestion.Text = reader["question"].ToString();

                    question[i]= reader["question"].ToString();
                    ans1[i]= reader["ans1"].ToString();
                    ans2[i] = reader["ans2"].ToString();
                    ans3[i] = reader["ans3"].ToString();
                    correctAns[i] = reader["correctAns"].ToString();
                    i++;
                }

                // display the first question and its answers
                nextQ = 0;
                this.lblQuestion.Text = question[nextQ];
                this.rbAns1.Text = ans1[nextQ];
                this.rbAns2.Text = ans2[nextQ];
                this.rbAns3.Text = ans3[nextQ];
                this.lblQno.Text = (nextQ + 1).ToString();

                nextQ++;

                dispatcherTimer = null;

                // are we playing a timed game?
                if (gameType == clsUtilis.TIMED)
                {
                    // display time fields
                    mainWindow.Instance.showTimeLeftFields();

                    // start a 1 second timer
                    timeLeft = 30;
                    dispatcherTimer = new DispatcherTimer(); 
                    dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
                    dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
                    dispatcherTimer.Start();

                }
            }
            else
                MessageBox.Show("Data not found in the DB!");

        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (timeLeft <= 0)
            {
                // hide time fields
                mainWindow.Instance.hideTimeLeftFields();

                // stop the timer
                dispatcherTimer.Stop();

                // update the score
                MessageBox.Show("End of game. You Scored : " + score.ToString());

                // end the game and return to the Topic form
                btnEndGame_Click(sender, e);

            }
            else
            {
                // update time
                timeLeft--;
                mainWindow.Instance.topPanelContainer.Controls["lblTimeLeft"].Text = timeLeft.ToString();

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEndGame_Click(object sender, EventArgs e)
        {
            string sqlQuery;
            OleDbDataReader reader;
            int heighestScore;
            int lastScore;

            // reset controls
            this.rbAns1.Checked = false;
            this.rbAns2.Checked = false;
            this.rbAns3.Checked = false;
            this.lblQno.Text = "Q#";
            this.lblQuestion.Text = "Question";
            this.rbAns1.Text = "Answere 1";
            this.rbAns2.Text = "Answere 2";
            this.rbAns3.Text = "Answere 3";

            mainWindow.Instance.mainPanelContainer.Dock = DockStyle.Fill;
            mainWindow.Instance.mainPanelContainer.Show();
            mainWindow.Instance.mainPanelContainer.BringToFront();

            // display the buttons on the left panel
            mainWindow.Instance.showLeftSidePanelControls();

            // display the logout button
            mainWindow.Instance.sidePanelContainerLeft.Controls["btnLogout"].Show();

            // hide top panel controls in the main window
            mainWindow.Instance.hideTopPanelControls();

            // hide time fields
            mainWindow.Instance.hideTimeLeftFields();

            // stop the timer
            if (this.dispatcherTimer != null)
                this.dispatcherTimer.Stop();

            if (this.atLeastOneQanswered ==true)
            {
                // update DB

                // first get the users heighest score
                
                sqlQuery = "SELECT heighestScore FROM users WHERE userName = '" + ucLogin.Instance.userName + "'";

                // set-up the connection to the DB
                clsDButils.connectToDB();

                // execute the SQL query
                reader = clsDButils.getData(sqlQuery);

                heighestScore = -1;
                lastScore = -1;

                if (reader != null)
                {
                    // should only get 1 record
                    while (reader.Read())
                    {
                        heighestScore = (int)reader["heighestScore"];
//                        lastScore = (int)reader["lastScore"];

                        if (this.score > heighestScore)
                            heighestScore = this.score;
                    }
                }

                // close connection to DB
                clsDButils.closeConnection();

                clsDButils.updateScore(ucLogin.Instance.userName, this.score, heighestScore);

                mainWindow.Instance.bottomPanelContainer.Controls["lblLastGameScore"].Text = this.score.ToString();
                mainWindow.Instance.bottomPanelContainer.Controls["lblHeighestScore"].Text = heighestScore.ToString();

            }

            // hide this panel
            this.Hide();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmitAns_Click(object sender, EventArgs e)
        {
            // check and update the score

            // which answer is selected and is it the correct answer?
            if ((this.rbAns1.Checked) || (this.rbAns2.Checked) || (this.rbAns3.Checked))
            {

                if (((this.rbAns1.Checked) && (this.rbAns1.Text == correctAns[nextQ-1])) ||
                    ((this.rbAns2.Checked) && (this.rbAns2.Text == correctAns[nextQ-1])) ||
                    ((this.rbAns3.Checked) && (this.rbAns3.Text == correctAns[nextQ-1])))
                {
                    // correct answer selected

                    // update the score
                    this.score = this.score + this.questionDifficulty;
                }
                else
                {
                    // incorrect answer selected
                    if (this.gameType == clsUtilis.CHALLENGE)
                    {
                        this.score = this.score - this.questionDifficulty;
                    }
                }
            }
            else
            {
                // no answer is selected

                if (this.gameType == clsUtilis.CHALLENGE)
                {
                    this.score = this.score - this.questionDifficulty;
                }

            }

            this.atLeastOneQanswered = true;

            // display the score
            mainWindow.Instance.setScore(this.score.ToString());


            // if not all questions in the category/difficulty have been answered display the next Q
            if (this.nextQ < this.recCount)
            {
                this.lblQuestion.Text = this.question[this.nextQ];
                this.rbAns1.Text = ans1[this.nextQ];
                this.rbAns2.Text = ans2[this.nextQ];
                this.rbAns3.Text = ans3[this.nextQ];

                this.lblQno.Text = (this.nextQ + 1).ToString();
                // TO DO
                // instead of just displaying the Q number, display Q number/Number of Qs in the category/difficulty
                // e.g. 4/10 (i.e. this is the 4th Q out of 10)

                this.nextQ++;


                // reset the answeres
                this.rbAns1.Checked = false;
                this.rbAns2.Checked = false;
                this.rbAns3.Checked = false;

            }
            else
            {
                // no more questions

                // display the score
                MessageBox.Show("End of game. You Scored : " + this.score.ToString());

                // end the game and return to the Topic form
                btnEndGame_Click(sender, e);
            }
        }
    }
}
