﻿namespace WindowsFormsApp
{
    partial class ucTopics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbBasic = new System.Windows.Forms.RadioButton();
            this.rbAdvance = new System.Windows.Forms.RadioButton();
            this.rbExpert = new System.Windows.Forms.RadioButton();
            this.gDifficulty = new System.Windows.Forms.GroupBox();
            this.rbNormal = new System.Windows.Forms.RadioButton();
            this.rbTimed = new System.Windows.Forms.RadioButton();
            this.rbChallenge = new System.Windows.Forms.RadioButton();
            this.grGameType = new System.Windows.Forms.GroupBox();
            this.llGeography = new System.Windows.Forms.LinkLabel();
            this.llHistory = new System.Windows.Forms.LinkLabel();
            this.llGeneralKnowledge = new System.Windows.Forms.LinkLabel();
            this.llSports = new System.Windows.Forms.LinkLabel();
            this.grTopics = new System.Windows.Forms.GroupBox();
            this.gDifficulty.SuspendLayout();
            this.grGameType.SuspendLayout();
            this.grTopics.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbBasic
            // 
            this.rbBasic.AutoSize = true;
            this.rbBasic.Checked = true;
            this.rbBasic.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbBasic.Location = new System.Drawing.Point(58, 79);
            this.rbBasic.Name = "rbBasic";
            this.rbBasic.Size = new System.Drawing.Size(157, 60);
            this.rbBasic.TabIndex = 3;
            this.rbBasic.TabStop = true;
            this.rbBasic.Text = "Basic";
            this.rbBasic.UseVisualStyleBackColor = true;
            this.rbBasic.CheckedChanged += new System.EventHandler(this.rbBasic_CheckedChanged);
            // 
            // rbAdvance
            // 
            this.rbAdvance.AutoSize = true;
            this.rbAdvance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbAdvance.Location = new System.Drawing.Point(58, 149);
            this.rbAdvance.Name = "rbAdvance";
            this.rbAdvance.Size = new System.Drawing.Size(217, 60);
            this.rbAdvance.TabIndex = 2;
            this.rbAdvance.Text = "Advance";
            this.rbAdvance.UseVisualStyleBackColor = true;
            this.rbAdvance.CheckedChanged += new System.EventHandler(this.rbAdvance_CheckedChanged);
            // 
            // rbExpert
            // 
            this.rbExpert.AutoSize = true;
            this.rbExpert.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbExpert.Location = new System.Drawing.Point(58, 219);
            this.rbExpert.Name = "rbExpert";
            this.rbExpert.Size = new System.Drawing.Size(191, 60);
            this.rbExpert.TabIndex = 1;
            this.rbExpert.Text = "Expert";
            this.rbExpert.UseVisualStyleBackColor = true;
            this.rbExpert.CheckedChanged += new System.EventHandler(this.rbExpert_CheckedChanged);
            // 
            // gDifficulty
            // 
            this.gDifficulty.Controls.Add(this.rbExpert);
            this.gDifficulty.Controls.Add(this.rbAdvance);
            this.gDifficulty.Controls.Add(this.rbBasic);
            this.gDifficulty.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gDifficulty.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gDifficulty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gDifficulty.Location = new System.Drawing.Point(878, 447);
            this.gDifficulty.Name = "gDifficulty";
            this.gDifficulty.Size = new System.Drawing.Size(391, 338);
            this.gDifficulty.TabIndex = 1;
            this.gDifficulty.TabStop = false;
            this.gDifficulty.Text = "Difficulty";
            // 
            // rbNormal
            // 
            this.rbNormal.AutoSize = true;
            this.rbNormal.Checked = true;
            this.rbNormal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbNormal.Location = new System.Drawing.Point(58, 84);
            this.rbNormal.Name = "rbNormal";
            this.rbNormal.Size = new System.Drawing.Size(195, 60);
            this.rbNormal.TabIndex = 3;
            this.rbNormal.TabStop = true;
            this.rbNormal.Text = "Normal";
            this.rbNormal.UseVisualStyleBackColor = true;
            this.rbNormal.CheckedChanged += new System.EventHandler(this.rbNormal_CheckedChanged);
            // 
            // rbTimed
            // 
            this.rbTimed.AutoSize = true;
            this.rbTimed.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbTimed.Location = new System.Drawing.Point(58, 154);
            this.rbTimed.Name = "rbTimed";
            this.rbTimed.Size = new System.Drawing.Size(176, 60);
            this.rbTimed.TabIndex = 2;
            this.rbTimed.Text = "Timed";
            this.rbTimed.UseVisualStyleBackColor = true;
            this.rbTimed.CheckedChanged += new System.EventHandler(this.rbTimed_CheckedChanged);
            // 
            // rbChallenge
            // 
            this.rbChallenge.AutoSize = true;
            this.rbChallenge.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rbChallenge.Location = new System.Drawing.Point(58, 224);
            this.rbChallenge.Name = "rbChallenge";
            this.rbChallenge.Size = new System.Drawing.Size(236, 60);
            this.rbChallenge.TabIndex = 1;
            this.rbChallenge.Text = "Challenge";
            this.rbChallenge.UseVisualStyleBackColor = true;
            this.rbChallenge.CheckedChanged += new System.EventHandler(this.rbChallenge_CheckedChanged);
            // 
            // grGameType
            // 
            this.grGameType.Controls.Add(this.rbChallenge);
            this.grGameType.Controls.Add(this.rbTimed);
            this.grGameType.Controls.Add(this.rbNormal);
            this.grGameType.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grGameType.ForeColor = System.Drawing.Color.Fuchsia;
            this.grGameType.Location = new System.Drawing.Point(878, 53);
            this.grGameType.Name = "grGameType";
            this.grGameType.Size = new System.Drawing.Size(391, 337);
            this.grGameType.TabIndex = 2;
            this.grGameType.TabStop = false;
            this.grGameType.Text = "Game Type";
            // 
            // llGeography
            // 
            this.llGeography.AutoSize = true;
            this.llGeography.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llGeography.LinkColor = System.Drawing.Color.Red;
            this.llGeography.Location = new System.Drawing.Point(35, 390);
            this.llGeography.Name = "llGeography";
            this.llGeography.Size = new System.Drawing.Size(298, 75);
            this.llGeography.TabIndex = 9;
            this.llGeography.TabStop = true;
            this.llGeography.Text = "Geography";
            // 
            // llHistory
            // 
            this.llHistory.AutoSize = true;
            this.llHistory.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llHistory.LinkColor = System.Drawing.Color.Red;
            this.llHistory.Location = new System.Drawing.Point(35, 259);
            this.llHistory.Name = "llHistory";
            this.llHistory.Size = new System.Drawing.Size(207, 75);
            this.llHistory.TabIndex = 9;
            this.llHistory.TabStop = true;
            this.llHistory.Text = "History";
            // 
            // llGeneralKnowledge
            // 
            this.llGeneralKnowledge.AutoSize = true;
            this.llGeneralKnowledge.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llGeneralKnowledge.LinkColor = System.Drawing.Color.Red;
            this.llGeneralKnowledge.Location = new System.Drawing.Point(35, 521);
            this.llGeneralKnowledge.Name = "llGeneralKnowledge";
            this.llGeneralKnowledge.Size = new System.Drawing.Size(509, 75);
            this.llGeneralKnowledge.TabIndex = 9;
            this.llGeneralKnowledge.TabStop = true;
            this.llGeneralKnowledge.Text = "General Knowledge";
            // 
            // llSports
            // 
            this.llSports.AutoSize = true;
            this.llSports.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llSports.LinkColor = System.Drawing.Color.Red;
            this.llSports.Location = new System.Drawing.Point(35, 128);
            this.llSports.Name = "llSports";
            this.llSports.Size = new System.Drawing.Size(165, 75);
            this.llSports.TabIndex = 9;
            this.llSports.TabStop = true;
            this.llSports.Text = "Sport";
            this.llSports.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llSports_LinkClicked);
            // 
            // grTopics
            // 
            this.grTopics.Controls.Add(this.llSports);
            this.grTopics.Controls.Add(this.llGeneralKnowledge);
            this.grTopics.Controls.Add(this.llHistory);
            this.grTopics.Controls.Add(this.llGeography);
            this.grTopics.Dock = System.Windows.Forms.DockStyle.Left;
            this.grTopics.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grTopics.Location = new System.Drawing.Point(0, 0);
            this.grTopics.Name = "grTopics";
            this.grTopics.Size = new System.Drawing.Size(829, 1122);
            this.grTopics.TabIndex = 4;
            this.grTopics.TabStop = false;
            this.grTopics.Text = "Category";
            // 
            // ucTopics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grTopics);
            this.Controls.Add(this.grGameType);
            this.Controls.Add(this.gDifficulty);
            this.Name = "ucTopics";
            this.Size = new System.Drawing.Size(2275, 1122);
            this.Load += new System.EventHandler(this.ucTopics_Load);
            this.gDifficulty.ResumeLayout(false);
            this.gDifficulty.PerformLayout();
            this.grGameType.ResumeLayout(false);
            this.grGameType.PerformLayout();
            this.grTopics.ResumeLayout(false);
            this.grTopics.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbBasic;
        private System.Windows.Forms.RadioButton rbAdvance;
        private System.Windows.Forms.RadioButton rbExpert;
        private System.Windows.Forms.GroupBox gDifficulty;
        private System.Windows.Forms.RadioButton rbNormal;
        private System.Windows.Forms.RadioButton rbTimed;
        private System.Windows.Forms.RadioButton rbChallenge;
        private System.Windows.Forms.GroupBox grGameType;
        private System.Windows.Forms.LinkLabel llGeography;
        private System.Windows.Forms.LinkLabel llHistory;
        private System.Windows.Forms.LinkLabel llGeneralKnowledge;
        private System.Windows.Forms.LinkLabel llSports;
        private System.Windows.Forms.GroupBox grTopics;
    }
}
