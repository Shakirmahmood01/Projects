﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class ucViewProfile : UserControl
    {
        private static ucViewProfile _instance;

        public static ucViewProfile Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucViewProfile();                
                return _instance;
            }
        }

        public ucViewProfile()
        {
            InitializeComponent();
        }

        private void ucViewProfile_Load(object sender, EventArgs e)
        {

        }
    }
}
