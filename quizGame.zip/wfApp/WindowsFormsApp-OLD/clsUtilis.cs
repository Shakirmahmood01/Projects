﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp
{
    public static class clsUtilis
    {
        public static string SPORTS = "Sports";
        public static string GEOGRAPHY = "Geography";
        public static string GENERAL_KNOWLEDGE = "General Knowledge";
        public static string HISTORY = "History";

        public static int BASIC = 1;
        public static int ADVANCE = 2;
        public static int EXPERT = 3;


        public static string NORMAL = "Normal";
        public static string TIMED = "Timed";
        public static string CHALLENGE = "Challenge";


        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}
