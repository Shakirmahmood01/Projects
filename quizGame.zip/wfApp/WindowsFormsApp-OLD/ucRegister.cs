﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace WindowsFormsApp
{
    public partial class ucRegister : UserControl
    {
        public ucRegister()
        {
            InitializeComponent();
        }


        private static ucRegister _instance;

        public static ucRegister Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucRegister();
                return _instance;
            }
        }


        //*******************************************************************
        // will check if the supplied user name exist within the DB
        private Boolean validUser(string userName)
        {
            string sqlQuery;
            OleDbDataReader reader;
            Boolean retVal;

            // create the query
            sqlQuery = "SELECT * FROM users WHERE userName = '" + userName + "'";

            // open connection to DB
            clsDButils.connectToDB();

            // run query
            reader = clsDButils.getData(sqlQuery);

            retVal = true;

            // did the query return any data?
            if (reader != null)
                retVal = false;

            clsDButils.closeConnection();

            return retVal;
            
        } // validUser

        //*******************************************************************

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string strQ1;
            string strQ2;
            string strQ3;
            string strUserName;
            string strEmail;

            string strPW1;


            // get the typed in user name
            strUserName = txtUserName.Text;

            strEmail = txtEmail.Text;

            // check if a valid email address is entered
            if (!clsUtilis.IsValidEmail(strEmail))
            {
                MessageBox.Show("Please enter a valid Email address!");
                return;
            }


            /////// TO DO CHECK IF USER HAS ENTERED ALL INFORMATION
            /// DO NOT WANT EMPTY FIELDS

            // check if a user with the same username already exists
            if (validUser(strUserName) == true)
            {
                // check if the PWs match

                if (txtNewPW1.Text == txtNewPW2.Text)
                { 
                    // encrypt the PW
                    strPW1 = clsEncrypt.encryptTxt(txtNewPW1.Text);
                    // we have a valid user name and passwords match
                    // add this user to the system DB

                    // get answer to Q1
                    strQ1 = clsEncrypt.encryptTxt(txtQ1.Text);

                    // get answer to Q2
                    strQ2 = clsEncrypt.encryptTxt(txtQ2.Text);

                    // get answer to Q3
                    strQ3 = clsEncrypt.encryptTxt(txtQ3.Text);

                    // add user to DB
                    if (clsDButils.addUser(strUserName, strEmail,strPW1, strQ1, strQ2, strQ3))
                    {
                        MessageBox.Show("User Added");

                        // clear the form
                        clearForm();

                        displayLoginForm();

                    }
                    else
                        MessageBox.Show("Error Adding New User!");


                }
                else
                    MessageBox.Show("Passwords do not match.\nEnsure that the eneterd passwords are same.");

            }
            else
                MessageBox.Show("This username is taken.\nPlease choose a different username.");
        }

        //*******************************************************************
        private void displayLoginForm()
        {
            // hide this panel
            this.Hide();

            // bring-up the login form
            if (!mainWindow.Instance.mainPanelContainer.Controls.Contains(ucLogin.Instance))
            {
                mainWindow.Instance.mainPanelContainer.Controls.Add(ucLogin.Instance);
                ucLogin.Instance.Dock = DockStyle.Fill;
                ucLogin.Instance.BringToFront();
            }
            else
            {
                ucLogin.Instance.Show();
                ucLogin.Instance.BringToFront();
            }

        } // displayLoginForm


        //*******************************************************************
        private void clearForm()
        {
            this.txtNewPW1.Text = "";
            this.txtNewPW2.Text = "";
            this.txtQ1.Text = "";
            this.txtQ2.Text = "";
            this.txtQ3.Text = "";
            this.txtUserName.Text = "";

        } // clearForm

        //*******************************************************************
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // clear the form
            clearForm();

            displayLoginForm();

        }
    }
}
