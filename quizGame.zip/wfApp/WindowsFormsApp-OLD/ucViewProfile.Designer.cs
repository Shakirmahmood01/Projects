﻿namespace WindowsFormsApp
{
    partial class ucViewProfile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblRank = new System.Windows.Forms.Label();
            this.txtRank = new System.Windows.Forms.TextBox();
            this.lblHighScore = new System.Windows.Forms.Label();
            this.txtHighestScore = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(34, 216);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(141, 59);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(200, 237);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(507, 38);
            this.txtName.TabIndex = 1;
            // 
            // lblRank
            // 
            this.lblRank.AutoSize = true;
            this.lblRank.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRank.Location = new System.Drawing.Point(777, 221);
            this.lblRank.Name = "lblRank";
            this.lblRank.Size = new System.Drawing.Size(121, 59);
            this.lblRank.TabIndex = 0;
            this.lblRank.Text = "Rank";
            // 
            // txtRank
            // 
            this.txtRank.Location = new System.Drawing.Point(940, 237);
            this.txtRank.Name = "txtRank";
            this.txtRank.Size = new System.Drawing.Size(199, 38);
            this.txtRank.TabIndex = 1;
            // 
            // lblHighScore
            // 
            this.lblHighScore.AutoSize = true;
            this.lblHighScore.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHighScore.Location = new System.Drawing.Point(1209, 221);
            this.lblHighScore.Name = "lblHighScore";
            this.lblHighScore.Size = new System.Drawing.Size(290, 59);
            this.lblHighScore.TabIndex = 0;
            this.lblHighScore.Text = "Highest Score";
            // 
            // txtHighestScore
            // 
            this.txtHighestScore.Location = new System.Drawing.Point(1515, 232);
            this.txtHighestScore.Name = "txtHighestScore";
            this.txtHighestScore.Size = new System.Drawing.Size(199, 38);
            this.txtHighestScore.TabIndex = 1;
            // 
            // ucViewProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtHighestScore);
            this.Controls.Add(this.txtRank);
            this.Controls.Add(this.lblHighScore);
            this.Controls.Add(this.lblRank);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Name = "ucViewProfile";
            this.Size = new System.Drawing.Size(2275, 1122);
            this.Load += new System.EventHandler(this.ucViewProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblRank;
        private System.Windows.Forms.TextBox txtRank;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.TextBox txtHighestScore;
    }
}
