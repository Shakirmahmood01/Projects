﻿namespace WindowsFormsApp
{
    partial class mainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainWindow));
            this.sidePanelLeft = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.marker = new System.Windows.Forms.Panel();
            this.btnViewAccInfo = new System.Windows.Forms.Button();
            this.btnChooseTopic = new System.Windows.Forms.Button();
            this.bottomPanel = new System.Windows.Forms.Panel();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.topPanel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblGameDifficulty = new System.Windows.Forms.Label();
            this.lblGameType = new System.Windows.Forms.Label();
            this.lblTopic = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblUser = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblLastGameScore = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTimeLeft = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblHeighestScore = new System.Windows.Forms.Label();
            this.sidePanelLeft.SuspendLayout();
            this.bottomPanel.SuspendLayout();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.topPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidePanelLeft
            // 
            this.sidePanelLeft.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sidePanelLeft.Controls.Add(this.btnExit);
            this.sidePanelLeft.Controls.Add(this.btnLogout);
            this.sidePanelLeft.Controls.Add(this.marker);
            this.sidePanelLeft.Controls.Add(this.btnViewAccInfo);
            this.sidePanelLeft.Controls.Add(this.btnChooseTopic);
            resources.ApplyResources(this.sidePanelLeft, "sidePanelLeft");
            this.sidePanelLeft.Name = "sidePanelLeft";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Maroon;
            this.btnExit.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnExit, "btnExit");
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Name = "btnExit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Black;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnLogout, "btnLogout");
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // marker
            // 
            this.marker.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.marker, "marker");
            this.marker.Name = "marker";
            // 
            // btnViewAccInfo
            // 
            this.btnViewAccInfo.BackColor = System.Drawing.Color.Black;
            this.btnViewAccInfo.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnViewAccInfo, "btnViewAccInfo");
            this.btnViewAccInfo.ForeColor = System.Drawing.Color.White;
            this.btnViewAccInfo.Name = "btnViewAccInfo";
            this.btnViewAccInfo.UseVisualStyleBackColor = false;
            this.btnViewAccInfo.Click += new System.EventHandler(this.btnViewAccInfo_Click);
            // 
            // btnChooseTopic
            // 
            this.btnChooseTopic.BackColor = System.Drawing.Color.Black;
            this.btnChooseTopic.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnChooseTopic, "btnChooseTopic");
            this.btnChooseTopic.ForeColor = System.Drawing.Color.White;
            this.btnChooseTopic.Name = "btnChooseTopic";
            this.btnChooseTopic.UseVisualStyleBackColor = false;
            this.btnChooseTopic.Click += new System.EventHandler(this.btnChooseTopic_Click);
            // 
            // bottomPanel
            // 
            this.bottomPanel.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.bottomPanel.Controls.Add(this.lblHeighestScore);
            this.bottomPanel.Controls.Add(this.lblLastGameScore);
            this.bottomPanel.Controls.Add(this.label7);
            this.bottomPanel.Controls.Add(this.label5);
            this.bottomPanel.Controls.Add(this.lblUser);
            resources.ApplyResources(this.bottomPanel, "bottomPanel");
            this.bottomPanel.Name = "bottomPanel";
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Tan;
            this.mainPanel.Controls.Add(this.pictureBox1);
            resources.ApplyResources(this.mainPanel, "mainPanel");
            this.mainPanel.Name = "mainPanel";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // topPanel
            // 
            this.topPanel.Controls.Add(this.label6);
            this.topPanel.Controls.Add(this.label4);
            this.topPanel.Controls.Add(this.label3);
            this.topPanel.Controls.Add(this.label2);
            this.topPanel.Controls.Add(this.label1);
            this.topPanel.Controls.Add(this.lblTimeLeft);
            this.topPanel.Controls.Add(this.lblScore);
            this.topPanel.Controls.Add(this.lblGameDifficulty);
            this.topPanel.Controls.Add(this.lblGameType);
            this.topPanel.Controls.Add(this.lblTopic);
            resources.ApplyResources(this.topPanel, "topPanel");
            this.topPanel.Name = "topPanel";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblScore
            // 
            resources.ApplyResources(this.lblScore, "lblScore");
            this.lblScore.ForeColor = System.Drawing.Color.Black;
            this.lblScore.Name = "lblScore";
            // 
            // lblGameDifficulty
            // 
            resources.ApplyResources(this.lblGameDifficulty, "lblGameDifficulty");
            this.lblGameDifficulty.ForeColor = System.Drawing.Color.Black;
            this.lblGameDifficulty.Name = "lblGameDifficulty";
            // 
            // lblGameType
            // 
            resources.ApplyResources(this.lblGameType, "lblGameType");
            this.lblGameType.ForeColor = System.Drawing.Color.Black;
            this.lblGameType.Name = "lblGameType";
            // 
            // lblTopic
            // 
            resources.ApplyResources(this.lblTopic, "lblTopic");
            this.lblTopic.ForeColor = System.Drawing.Color.Black;
            this.lblTopic.Name = "lblTopic";
            // 
            // lblUser
            // 
            resources.ApplyResources(this.lblUser, "lblUser");
            this.lblUser.ForeColor = System.Drawing.Color.Red;
            this.lblUser.Name = "lblUser";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Name = "label5";
            // 
            // lblLastGameScore
            // 
            resources.ApplyResources(this.lblLastGameScore, "lblLastGameScore");
            this.lblLastGameScore.ForeColor = System.Drawing.Color.Black;
            this.lblLastGameScore.Name = "lblLastGameScore";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Name = "label6";
            this.label6.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblTimeLeft
            // 
            resources.ApplyResources(this.lblTimeLeft, "lblTimeLeft");
            this.lblTimeLeft.ForeColor = System.Drawing.Color.Black;
            this.lblTimeLeft.Name = "lblTimeLeft";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Name = "label7";
            // 
            // lblHeighestScore
            // 
            resources.ApplyResources(this.lblHeighestScore, "lblHeighestScore");
            this.lblHeighestScore.ForeColor = System.Drawing.Color.Black;
            this.lblHeighestScore.Name = "lblHeighestScore";
            // 
            // mainWindow
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.bottomPanel);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.sidePanelLeft);
            this.IsMdiContainer = true;
            this.Name = "mainWindow";
            this.Load += new System.EventHandler(this.mainWindow_Load);
            this.sidePanelLeft.ResumeLayout(false);
            this.bottomPanel.ResumeLayout(false);
            this.bottomPanel.PerformLayout();
            this.mainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidePanelLeft;
        private System.Windows.Forms.Panel bottomPanel;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Button btnChooseTopic;
        private System.Windows.Forms.Button btnViewAccInfo;
        private System.Windows.Forms.Panel marker;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTopic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblGameDifficulty;
        private System.Windows.Forms.Label lblGameType;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lblLastGameScore;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblTimeLeft;
        private System.Windows.Forms.Label lblHeighestScore;
        private System.Windows.Forms.Label label7;
    }
}

