﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp
{

    public static class clsEncrypt
    {

        //*******************************************************************
        /// <summary>
        /// very basic encryption.
        /// encrypts a text field value for 
        /// comparing against the stored value in the DB
        /// </summary>
        /// <returns> </returns>
        public static string encryptTxt(string txt)
        {
            int i;
            char aChar;
            char[] txtChars; // holds the textbox chars e.g. 'P','A','S','S','W','O','R','D'
            int intChar;
            int[] charsTxt; // holds the ascii value of the textbox
            string encryptedTxt;

            // convert it into a char array
            txtChars = txt.ToCharArray(0, txt.Length);

            // set the size of the array to be long enough to hold the entered text
            charsTxt = new int[txt.Length];

            i = 0;
            // go through each of the textbox char
            foreach (char c in txtChars)
            {
                //Debug.Print (c.ToString());

                // get chars ascii value
                intChar = Convert.ToInt32(c);

                // check if the ascii value is a printable char
                if (intChar >= 32 && intChar <= 126)
                {
                    // encrypt the textbox value
                    // substitute a different char for it
                    intChar = intChar + 3;

                    // check if will get pass 126 and if so then wrap it around
                    if (intChar > 126)
                    {
                        intChar = 32 + (intChar % 126);
                    }
                    charsTxt[i++] = intChar;
                    //Debug.Print (charsTxt[i-1].ToString());
                }
                else
                {
                    // illegal chars entered in the textbox.
                    // do nothing.
                }

            } // foreach c


            // convert the text value into a string
            encryptedTxt = "";
            foreach (int x in charsTxt)
            {
                // convert the integer value into a char
                aChar = Convert.ToChar(x);

                // add the char to the txt field
                encryptedTxt += x.ToString();
            }

            return encryptedTxt;

        } // encryptTxt

    } // clsEncrypt
}
