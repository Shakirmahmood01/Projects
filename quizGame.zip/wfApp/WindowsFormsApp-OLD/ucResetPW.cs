﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;


namespace WindowsFormsApp
{
    public partial class ucResetPW : UserControl
    {
        public ucResetPW()
        {
            InitializeComponent();
        }

        private static ucResetPW _instance;

        public static ucResetPW Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ucResetPW();
                return _instance;
            }
        }


        //*******************************************************************
        // will check if the supplied user name and the answers to the user questions
        // exist within the DB
        private Boolean validateUser(string userName, string strQ1Ans, string strQ2Ans,string strQ3Ans)
        {
            OleDbConnection con;
            string sqlQuery;
            OleDbDataReader reader;
            OleDbCommand cmd;
            Boolean validUser;

            //MessageBox.Show(userName+"///" + strQ1Ans + "///");

            // create the query
            sqlQuery = "SELECT * FROM users WHERE userName = '" + userName + "' AND  q1Ans  = '" + strQ1Ans + "' AND  q2Ans  = '" + strQ2Ans + "' AND  q3Ans  = '" + strQ3Ans + "'";

            // open connection to DB
            clsDButils.connectToDB();

            // run query
            reader = clsDButils.getData(sqlQuery);

            // initialise - default no valid user found
            validUser = false;

            // did the query return any data?
            if (reader != null)
                validUser = true;

            clsDButils.closeConnection();

            return validUser;
        } // validateUser

        //*******************************************************************
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string strQ1;
            string strQ2;
            string strQ3;
            string strUserName;
            string strPW1;

            //string userName = ucLogin.Instance.userName;

            // get answer to Q1
            strQ1 = clsEncrypt.encryptTxt(txtQ1.Text);

            // get answer to Q2
            strQ2 = clsEncrypt.encryptTxt(txtQ2.Text);

            // get answer to Q3
            strQ3 = clsEncrypt.encryptTxt(txtQ3.Text);

            // get the typed in user name
            strUserName = txtUserName.Text;

            // check if the user name and answers to the 3 questions are valid i.e. it is an already registered user
            if (validateUser(strUserName, strQ1, strQ2, strQ3))
            {
                // found a registered user

                //MessageBox.Show("Valid User");

                // check if the PWs typed in match
                if (txtNewPW1.Text != txtNewPW2.Text)
                {
                    MessageBox.Show("Passwords entered do not match.");
                }
                else
                {
                    // encrypt the PW
                    strPW1 = clsEncrypt.encryptTxt(txtNewPW1.Text);

                    // valid user and passwords match so update the DB
                    if (clsDButils.upDatePassword(strPW1, strUserName))
                    {
                        MessageBox.Show("Password Reset)");

                        displayLoginForm();

                        // clear the form
                        clearForm();
                    }

                }

            }
            else
            {
                MessageBox.Show("Unable to verify the user.\nEither un-registered user or the answer(s) are incorrect.");
            }

        } // btnSubmit_Click


        //*******************************************************************
        private void displayLoginForm()
        {
            // hide the login panel
            this.Hide();

            // bring-up the login form
            if (!mainWindow.Instance.mainPanelContainer.Controls.Contains(ucLogin.Instance))
            {
                mainWindow.Instance.mainPanelContainer.Controls.Add(ucLogin.Instance);
                ucLogin.Instance.Dock = DockStyle.Fill;
                ucLogin.Instance.BringToFront();
            }
            else
            {
                ucLogin.Instance.Show();
                ucLogin.Instance.BringToFront();
            }

        } // displayLoginForm


        //*******************************************************************
        private void clearForm()
        {
            this.txtNewPW1.Text = "";
            this.txtNewPW2.Text = "";
            this.txtQ1.Text = "";
            this.txtQ2.Text = "";
            this.txtQ3.Text = "";
            this.txtUserName.Text = "";

        } // clearForm

        //*******************************************************************
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // clear the form
            clearForm();

            displayLoginForm();

        }
    }
}
